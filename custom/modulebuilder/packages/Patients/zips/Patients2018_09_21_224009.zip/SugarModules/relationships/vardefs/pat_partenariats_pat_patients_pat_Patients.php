<?php
// created: 2018-09-21 22:40:08
$dictionary["pat_Patients"]["fields"]["pat_partenariats_pat_patients"] = array (
  'name' => 'pat_partenariats_pat_patients',
  'type' => 'link',
  'relationship' => 'pat_partenariats_pat_patients',
  'source' => 'non-db',
  'module' => 'pat_Partenariats',
  'bean_name' => false,
  'vname' => 'LBL_PAT_PARTENARIATS_PAT_PATIENTS_FROM_PAT_PARTENARIATS_TITLE',
  'id_name' => 'pat_partenariats_pat_patientspat_partenariats_ida',
);
$dictionary["pat_Patients"]["fields"]["pat_partenariats_pat_patients_name"] = array (
  'name' => 'pat_partenariats_pat_patients_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_PAT_PARTENARIATS_PAT_PATIENTS_FROM_PAT_PARTENARIATS_TITLE',
  'save' => true,
  'id_name' => 'pat_partenariats_pat_patientspat_partenariats_ida',
  'link' => 'pat_partenariats_pat_patients',
  'table' => 'pat_partenariats',
  'module' => 'pat_Partenariats',
  'rname' => 'name',
);
$dictionary["pat_Patients"]["fields"]["pat_partenariats_pat_patientspat_partenariats_ida"] = array (
  'name' => 'pat_partenariats_pat_patientspat_partenariats_ida',
  'type' => 'link',
  'relationship' => 'pat_partenariats_pat_patients',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'left',
  'vname' => 'LBL_PAT_PARTENARIATS_PAT_PATIENTS_FROM_PAT_PARTENARIATS_TITLE',
);
